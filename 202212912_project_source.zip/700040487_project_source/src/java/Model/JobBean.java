/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Model;

import java.io.Serializable;
import java.util.Date;

public class JobBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String title;
    private String category;
    private String location;
    private String description;
    private Date postDate;

    public JobBean() {}

    public JobBean(int id, String title, String category, String location, String description, Date postDate) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.location = location;
        this.description = description;
        this.postDate = postDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getPostDate() {
        return postDate;
    }

    public void setPostDate(Date postDate) {
        this.postDate = postDate;
    }
}