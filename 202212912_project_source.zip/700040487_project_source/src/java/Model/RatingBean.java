/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Model;

import java.io.Serializable;
import java.util.Date;

public class RatingBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ratingId;
    private int companyId;
    private String userName;
    private int rating;
    private String comment;
    private Date datePosted;
    private String companyName;


    public RatingBean() {}
    
    public RatingBean(int companyId, String userName, int rating, String comment) {
        this.companyId = companyId;
        this.userName = userName;
        this.rating = rating;
        this.comment = comment;
    }

    public RatingBean(int ratingId, int companyId, String userName, int rating, String comment, Date datePosted) {
        this.ratingId = ratingId;
        this.companyId = companyId;
        this.userName = userName;
        this.rating = rating;
        this.comment = comment;
        this.datePosted = datePosted;
    }

    public int getRatingId() {
        return ratingId;
    }

    public void setRatingId(int ratingId) {
        this.ratingId = ratingId;
    }

    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getDatePosted() {
        return datePosted;
    }

    public void setDatePosted(Date datePosted) {
        this.datePosted = datePosted;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
