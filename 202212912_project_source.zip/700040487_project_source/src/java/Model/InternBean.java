/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Model;



import java.io.Serializable;


public class InternBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private int internId;
    private String name;
    private String email;
    private String phone;
    private String cvLink;

    public InternBean() {}

    public InternBean(int internId, String name, String email, String phone, String cvLink) {
        this.internId = internId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.cvLink = cvLink;
    }

    public int getInternId() {
        return internId;
    }

    public void setInternId(int internId) {
        this.internId = internId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCvLink() {
        return cvLink;
    }

    public void setCvLink(String cvLink) {
        this.cvLink = cvLink;
    }
}