/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Model;

public class UserBean {
    private String email;     // User's email
    private String password;  // User's password
    private String userType;  // Can be 'admin' or 'intern'
    private String name;      // User's name

    // Constructor
    public UserBean(String email, String password, String userType, String name) {
        this.email = email;
        this.password = password;
        this.userType = userType;
        this.name = name;
    }

    // Getters and Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
