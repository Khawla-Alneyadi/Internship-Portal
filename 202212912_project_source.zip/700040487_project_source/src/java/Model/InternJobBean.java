/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Model;

import java.io.Serializable;

public class InternJobBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private int internId;
    private int jobId;

    public InternJobBean() {
    }

    public InternJobBean(int internId, int jobId) {
        this.internId = internId;
        this.jobId = jobId;
    }

    public int getInternId() {
        return internId;
    }

    public void setInternId(int internId) {
        this.internId = internId;
    }

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }
}
