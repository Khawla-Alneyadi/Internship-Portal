/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

import Model.DBConnection;

@WebServlet("/DeleteJobServlet")
public class DeleteJobServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String jobIdStr = request.getParameter("jobId");

        if (jobIdStr == null || jobIdStr.isEmpty()) {
            response.sendRedirect("deletejob.jsp?message=Missing Job ID");
            return;
        }

        try {
            int jobId = Integer.parseInt(jobIdStr);
            Connection conn = DBConnection.getConnection();

            // Delete links to interns first
            PreparedStatement deleteLinks = conn.prepareStatement(
                "DELETE FROM login.intern_job WHERE job_id = ?"
            );
            deleteLinks.setInt(1, jobId);
            deleteLinks.executeUpdate();
            deleteLinks.close();

            // Delete the job
            PreparedStatement deleteJob = conn.prepareStatement(
                "DELETE FROM login.jobs WHERE id = ?"
            );
            deleteJob.setInt(1, jobId);
            int rows = deleteJob.executeUpdate();
            deleteJob.close();
            conn.close();

            if (rows > 0) {
                response.sendRedirect("deletejob.jsp?message=✅ Job deleted successfully.");
            } else {
                response.sendRedirect("deletejob.jsp?message=❌ Job not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("deletejob.jsp?message=❌ Error: " + e.getMessage());
        }
    }
}
