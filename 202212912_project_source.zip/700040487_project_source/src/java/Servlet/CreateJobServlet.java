/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

import Model.DBConnection;
import Model.LoginBean;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;
import jakarta.servlet.*;

import Model.DBConnection;

import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;


/**
 *
 * @author ahedo
 */
@WebServlet(name = "CreateJobServlet", urlPatterns = {"/CreateJobServlet"})
public class CreateJobServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
////            Integer companyId = (Integer) request.getSession().getAttribute("companyId");
//            HttpSession session = request.getSession(false);
//        if (session == null || session.getAttribute("email") == null) {
//            response.sendRedirect("index.jsp?message=Not logged in");
//            return;
//        }
//
//        String email = (String) session.getAttribute("email");
//        int companyId = -1;
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement ps = conn.prepareStatement("SELECT company_id FROM login.company WHERE email = ?")) {
//
//            ps.setString(1, email);
//            ResultSet rs = ps.executeQuery();
//
//            if (rs.next()) {
//                companyId = rs.getInt("company_id");
//            } else {
//                response.sendRedirect("index.jsp?message=Company not found");
//                return;
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            response.sendRedirect("index.jsp?message=Database error while fetching company id");
//            return;
//        }
//
//
//
//
//        String title = request.getParameter("title");
//        String location = request.getParameter("location");
//        String category = request.getParameter("category");
//        String description = request.getParameter("description");
//        String date = request.getParameter("date");
//        System.out.println("Title: " + title);
//        System.out.println("Location: " + location);
//        System.out.println("Category: " + category);
//        System.out.println("Description: " + description);
//        System.out.println("Date: " + date);
//
//        String sql = "INSERT INTO login.jobs (title, location, category, description, post_date,company_id) VALUES (?, ?, ?, ?,?, ?)";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(sql)) {
//
//            stmt.setString(1, title);
//            stmt.setString(2, location);
//            stmt.setString(3, category);
//            stmt.setString(4, description);
//            stmt.setString(5, date);
//            stmt.setInt(6, companyId); 
//            
//
//            stmt.executeUpdate();
//
////            response.sendRedirect("Jobs.jsp");
//            request.setAttribute("message", "Job added successfully!");
//            request.setAttribute("redirect", "companyView.jsp");
//            RequestDispatcher dispatcher = request.getRequestDispatcher("success.jsp");
//            dispatcher.forward(request, response);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            response.getWriter().println("Error: " + e.getMessage());
//        }
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
//            Integer companyId = (Integer) request.getSession().getAttribute("companyId");
            HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("index.jsp?message=Not logged in");
            return;
        }

        String email = (String) session.getAttribute("email");
        int companyId = -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT company_id FROM login.company WHERE email = ?")) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                companyId = rs.getInt("company_id");
            } else {
                response.sendRedirect("index.jsp?message=Company not found");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp?message=Database error while fetching company id");
            return;
        }




        String title = request.getParameter("title");
        String location = request.getParameter("location");
        String category = request.getParameter("category");
        String description = request.getParameter("description");
        String date = request.getParameter("date");
        System.out.println("Title: " + title);
        System.out.println("Location: " + location);
        System.out.println("Category: " + category);
        System.out.println("Description: " + description);
        System.out.println("Date: " + date);

        String sql = "INSERT INTO login.jobs (title, location, category, description, post_date,company_id) VALUES (?, ?, ?, ?,?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, location);
            stmt.setString(3, category);
            stmt.setString(4, description);
            stmt.setString(5, date);
            stmt.setInt(6, companyId); 
            

            stmt.executeUpdate();

//            response.sendRedirect("Jobs.jsp");
            request.setAttribute("message", "Job added successfully!");
            request.setAttribute("redirect", "companyView.jsp");
            RequestDispatcher dispatcher = request.getRequestDispatcher("operation_successful.jsp");
            dispatcher.forward(request, response);


        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
