/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import Model.DBConnection;
import Model.RatingBean;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

@WebServlet("/ReviewServlet")
public class ReviewServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            deleteReview(request, response);
        } else {
            listReviews(request, response);
        }
    }

    private void listReviews(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        ArrayList<RatingBean> reviews = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                "SELECT r.rating_id, r.user_name, c.company_name, r.rating, r.comment " +
                "FROM rating r JOIN company c ON r.company_id = c.company_id");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                RatingBean r = new RatingBean();
                r.setRatingId(rs.getInt("rating_id"));
                r.setUserName(rs.getString("user_name"));
                r.setCompanyName(rs.getString("company_name")); // ← We'll add this in the bean next
                r.setRating(rs.getInt("rating"));
                r.setComment(rs.getString("comment"));
                reviews.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("reviews", reviews);
        request.getRequestDispatcher("moderateReviews.jsp").forward(request, response);
    }

    private void deleteReview(HttpServletRequest request, HttpServletResponse response)
        throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM rating WHERE rating_id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.sendRedirect("ReviewServlet");
    }
}
