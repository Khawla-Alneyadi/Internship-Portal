/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Model.DBConnection;

@WebServlet("/PlatformStatsServlet")
public class AdminStatsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Read the company_id parameter
    
        
        // 1) Read the company_id parameter
        String cidStr = request.getParameter("company_id");
        int companyId = (cidStr != null) ? Integer.parseInt(cidStr) : 0;

        // Summary metrics
        int totalUsers = 0;
        int totalCompanies = 0;
        int totalReviews = 0;
        int totalJobs = 0;
        int totalApplications = 0;
        double avgRating = 0.0;

        // Distribution of ratings 1–5
        int[] ratingDist = {0,0,0,0,0};

        try (Connection conn = DBConnection.getConnection()) {
            // a) Total users (all interns)
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM login.intern")) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalUsers = rs.getInt(1);
                }
            }

            // b) Total companies
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM login.company")) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalCompanies = rs.getInt(1);
                }
            }

            // c) Total reviews & average rating
            try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) AS cnt, AVG(rating) AS avg_rt " +
                "  FROM login.rating " +
                " WHERE company_id = ?")) {
                ps.setInt(1, companyId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        totalReviews = rs.getInt("cnt");
                        avgRating = rs.getDouble("avg_rt");
                    }
                }
            }

            // d) Rating distribution
            try (PreparedStatement ps = conn.prepareStatement(
                "SELECT rating, COUNT(*) AS cnt " +
                "  FROM login.rating " +
                " WHERE company_id = ? " +
                " GROUP BY rating " +
                " ORDER BY rating")) {
                ps.setInt(1, companyId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int rating = rs.getInt("rating");
                        int cnt = rs.getInt("cnt");
                        if (rating >= 1 && rating <= 5) {
                            ratingDist[rating - 1] = cnt;
                        }
                    }
                }
            }

            // e) Total jobs
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM login.jobs WHERE company_id = ?")) {
                ps.setInt(1, companyId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalJobs = rs.getInt(1);
                }
            }

            // f) Total applications
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM login.intern_job WHERE company_id = ?")) {
                ps.setInt(1, companyId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalApplications = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Set attributes for JSP
        request.setAttribute("totalUsers", totalUsers);
        request.setAttribute("totalCompanies", totalCompanies);
        request.setAttribute("totalReviews", totalReviews);
        request.setAttribute("totalJobs", totalJobs);
        request.setAttribute("totalApplications", totalApplications);
        request.setAttribute("avgRating", avgRating);
        request.setAttribute("ratingDist", ratingDist);
        request.setAttribute("companyId", companyId);

        // Prepare JS-friendly arrays
        request.setAttribute("ratingLabels", "['1★','2★','3★','4★','5★']");
        request.setAttribute("ratingData", Arrays.toString(ratingDist));
        request.setAttribute("overviewLabels", "['Users','Companies','Reviews','Jobs','Applications']");
        request.setAttribute("overviewData", 
            String.format("[%d,%d,%d,%d,%d]", 
                totalUsers, totalCompanies, totalReviews, totalJobs, totalApplications));

        // Forward to JSP
        request.getRequestDispatcher("/adminStats.jsp").forward(request, response);
    }
}
    