/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

import Model.DBConnection;
import Model.LoginBean;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        

    

    String email = request.getParameter("email");
    String password = request.getParameter("password");

    LoginBean loginBean = new LoginBean(email, password);

    if (email != null && password != null) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT user_type, name FROM login.login WHERE email = ? AND password = ?")) {

            ps.setString(1, loginBean.getEmail());
            ps.setString(2, loginBean.getPassword());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                loginBean.setUserType(rs.getString("user_type"));
                String name = rs.getString("name");

                HttpSession session = request.getSession();
                session.setAttribute("email", loginBean.getEmail());
                session.setAttribute("userType", loginBean.getUserType());

                if (loginBean.getUserType().equals("intern")) {
                    session.setAttribute("internName", name);
                    response.sendRedirect("intern.jsp");
                } else if (loginBean.getUserType().equals("company")) {
                    // Now get company_id from the company table using email
                    
                    try (PreparedStatement companyStmt = conn.prepareStatement(
                            "SELECT company_id FROM login.company WHERE email = ?")) {

                        companyStmt.setString(1, loginBean.getEmail());
                        ResultSet companyRs = companyStmt.executeQuery();

                        if (companyRs.next()) {
                            int companyId = companyRs.getInt("company_id");
                            session.setAttribute("companyId", companyId); // MUST BE SET HERE
                        } else {
                            response.sendRedirect("index.jsp?message=Company not found.");
                            return;
                        }
                    }
                    response.sendRedirect("companyView.jsp");
                


                   
                    
// Redirect after login success
                } else if (loginBean.getUserType().equals("admin")) {
                    response.sendRedirect("admin.jsp");
                } else {
                    response.sendRedirect("index.jsp?message=Unauthorized access.");
                }
            } else {
                response.sendRedirect("index.jsp?message=Invalid credentials.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp?message=Database error.");
        }
    } else {
        response.sendRedirect("index.jsp?message=Please enter both fields.");
    }
}

protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.sendRedirect("index.jsp");
}

}

//    
//
//        String email = request.getParameter("email");
//        String password = request.getParameter("password");
//
//        LoginBean loginBean = new LoginBean(email, password);
//
//        if (email != null && password != null) {
//            try (Connection conn = DBConnection.getConnection();
//                 PreparedStatement ps = conn.prepareStatement(
//                         "SELECT user_type, name FROM login.login WHERE email = ? AND password = ?")) {
//
//                ps.setString(1, loginBean.getEmail());
//                ps.setString(2, loginBean.getPassword());
//                ResultSet rs = ps.executeQuery();
//                
//                if (rs.next()) {
//                    loginBean.setUserType(rs.getString("user_type"));
//                    String name = rs.getString("name");
//
//                    HttpSession session = request.getSession();
//                    session.setAttribute("email", loginBean.getEmail());
//                    session.setAttribute("userType", loginBean.getUserType());
//
//                    if (loginBean.getUserType().equals("intern")) {
//                        session.setAttribute("internName", name);
//                        response.sendRedirect("intern.jsp");
//                    } else if (loginBean.getUserType().equals("company")) {
//                        // Now get company_id from the company table using email
//                        try (PreparedStatement companyStmt = conn.prepareStatement(
//                                "SELECT company_id FROM login.company WHERE email = ?")) {
//
//                            companyStmt.setString(1, loginBean.getEmail());
//                            ResultSet companyRs = companyStmt.executeQuery();
//
//                            if (companyRs.next()) {
//                                int companyId = companyRs.getInt("company_id");
//                                session.setAttribute("companyId", companyId); // ✅ Store it in session
//                            } else {
//                                // Fallback if company not found
//                                response.sendRedirect("index.jsp?message=Company not found.");
//                                return;
//                            }
//                        }
//
//                        response.sendRedirect("companyView.jsp");
//                    }
//                        
//                         // companyId comes from your companies table
//
//                        
//                    } else if (loginBean.getUserType().equals("admin")) {
//                        response.sendRedirect("admin.jsp");
//                    } else {
//                        response.sendRedirect("index.jsp?message=Unauthorized access.");
//                    }
//                } else {
//                    response.sendRedirect("index.jsp?message=Invalid credentials.");
//                }
//
//            } catch (SQLException e) {
//                e.printStackTrace();
//                response.sendRedirect("index.jsp?message=Database error.");
//            }
//        } else {
//            response.sendRedirect("index.jsp?message=Please enter both fields.");
//        }
//    }
//
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.sendRedirect("index.jsp");
//    }}
//}
