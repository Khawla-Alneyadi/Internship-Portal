/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import Model.DBConnection;
import Model.RatingBean;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.*;

@WebServlet("/submitRating")
public class RatingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String companyIdStr = request.getParameter("company_id");
        String userName = request.getParameter("user_name");
        String ratingStr = request.getParameter("rating");
        String comment = request.getParameter("comment");

        try {
            int companyId = Integer.parseInt(companyIdStr);
            int ratingValue = Integer.parseInt(ratingStr);

            RatingBean rating = new RatingBean(companyId, userName, ratingValue, comment);

            try (Connection conn = DBConnection.getConnection()) {
                String query = "INSERT INTO login.rating (company_id, user_name, rating, comment, date_posted) VALUES (?, ?, ?, ?, NOW())";
                try (PreparedStatement ps = conn.prepareStatement(query)) {
                    ps.setInt(1, rating.getCompanyId());
                    ps.setString(2, rating.getUserName());
                    ps.setInt(3, rating.getRating());
                    ps.setString(4, rating.getComment());

                    int rows = ps.executeUpdate();
                    if (rows > 0) {
                        response.sendRedirect("company.jsp?company_id=" + companyId + "&success=true");
                    } else {
                        response.sendRedirect("company.jsp?company_id=" + companyId + "&error=true");
                    }
                }
            }
        } catch (Exception e) {
            response.sendRedirect("company.jsp?company_id=" + companyIdStr + "&error=" + e.getMessage());
        }
    }
}
