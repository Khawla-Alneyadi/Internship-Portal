/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;
import Model.JobBean;
import Model.DBConnection;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author ahedo
 */
@WebServlet(name = "UpdateJobServlet", urlPatterns = {"/UpdateJobServlet"})
public class UpdateJobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateJobServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UpdateJobServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int jobId = Integer.parseInt(request.getParameter("jobId"));
        String title = request.getParameter("title");
        String category = request.getParameter("category");
        String location = request.getParameter("location");
        String description = request.getParameter("description");

        String updateQuery = "UPDATE login.jobs SET title=?, category=?, location=?, description=? WHERE id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(updateQuery)) {

            stmt.setString(1, title);
            stmt.setString(2, category);
            stmt.setString(3, location);
            stmt.setString(4, description);
            stmt.setInt(5, jobId);

            int rowsUpdated = stmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                request.setAttribute("message", "Job updated successfully!");
                request.setAttribute("redirect", "manageJobsView.jsp");
                RequestDispatcher dispatcher = request.getRequestDispatcher("operation_successful.jsp");
                dispatcher.forward(request, response);
            } else {
                response.sendRedirect("manageJobsView.jsp?update=fail");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("Jobs.jsp?update=error");
        }
    }



 @Override
    public String getServletInfo() {
        return "Short description";
    }
    
}