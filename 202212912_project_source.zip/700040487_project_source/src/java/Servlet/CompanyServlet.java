/*

Khawla Alneyadi 202212912
Habiba Almetnawy 700040241
Ahad Orabi 700040487
Ghaya Alameri 202103413

*/
package Servlet;

import Model.CompanyBean;
import Model.DBConnection;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

@WebServlet("/CompanyServlet")
public class CompanyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "add":
                addCompany(request, response);
                break;
            case "delete":
                deleteCompany(request, response);
                break;
            case "updateForm":
                showUpdateForm(request, response);
                break;
            case "update":
                updateCompany(request, response);
                break;
            default:
                listCompanies(request, response);
                break;
        }
    }

    private void listCompanies(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<CompanyBean> companies = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT c.*, " +
                             "(SELECT COUNT(*) FROM rating r WHERE r.company_id = c.company_id) AS review_count " +
                             "FROM company c")) {

            while (rs.next()) {
                CompanyBean company = new CompanyBean();
                company.setCompanyId(rs.getInt("company_id"));
                company.setCompanyName(rs.getString("company_name"));
                company.setIndustry(rs.getString("industry"));
                company.setDescription(rs.getString("description"));
                company.setVision(rs.getString("vision"));
                company.setEmail(rs.getString("email"));
                company.setPassword(rs.getString("password"));
                company.setReviewCount(rs.getInt("review_count"));
                companies.add(company);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("companies", companies);
        request.getRequestDispatcher("manageCompanies.jsp").forward(request, response);
    }

    private void addCompany(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String name = request.getParameter("companyName");
        String industry = request.getParameter("industry");
        String description = request.getParameter("description");
        String vision = request.getParameter("vision");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {
            // Step 1: insert into company table
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO company (company_name, industry, description, vision, email, password) VALUES (?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, name);
            ps.setString(2, industry);
            ps.setString(3, description);
            ps.setString(4, vision);
            ps.setString(5, email);
            ps.setString(6, password);
            ps.executeUpdate();

            // Get the generated company_id
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int companyId = -1;
            if (generatedKeys.next()) {
                companyId = generatedKeys.getInt(1);
            }
            ps.close();

            // insert into login table
            if (companyId != -1) {
                PreparedStatement psLogin = conn.prepareStatement(
                        "INSERT INTO login (email, password, user_type, name, company_id) VALUES (?, ?, 'company', ?, ?)");
                psLogin.setString(1, email);
                psLogin.setString(2, password);
                psLogin.setString(3, name);
                psLogin.setInt(4, companyId);
                psLogin.executeUpdate();
                psLogin.close();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("CompanyServlet");
    }

    private void deleteCompany(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try (Connection conn = DBConnection.getConnection()) {

            // delete related reviews
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM rating WHERE company_id = ?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }

            // delete from login
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM login WHERE company_id = ?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }

            // delete from company
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM company WHERE company_id = ?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.sendRedirect("CompanyServlet");
    }

    private void showUpdateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        CompanyBean company = new CompanyBean();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM company WHERE company_id = ?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                company.setCompanyId(rs.getInt("company_id"));
                company.setCompanyName(rs.getString("company_name"));
                company.setIndustry(rs.getString("industry"));
                company.setDescription(rs.getString("description"));
                company.setVision(rs.getString("vision"));
                company.setEmail(rs.getString("email"));
                company.setPassword(rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("company", company);
        request.getRequestDispatcher("updateCompany.jsp").forward(request, response);
    }

    private void updateCompany(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("companyName");
        String industry = request.getParameter("industry");
        String description = request.getParameter("description");
        String vision = request.getParameter("vision");
        String email = request.getParameter("email"); 
        String password = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {

            //  update company table
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE company SET company_name=?, industry=?, description=?, vision=?, email=?, password=? WHERE company_id=?")) {
                ps.setString(1, name);
                ps.setString(2, industry);
                ps.setString(3, description);
                ps.setString(4, vision);
                ps.setString(5, email);
                ps.setString(6, password);
                ps.setInt(7, id);
                ps.executeUpdate();
            }

            // update login table
            try (PreparedStatement psLogin = conn.prepareStatement(
                    "UPDATE login SET email = ?, password = ? WHERE company_id = ?")) {
                psLogin.setString(1, email);
                psLogin.setString(2, password);
                psLogin.setInt(3, id);
                psLogin.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("CompanyServlet");
    }
}
